
import streamlit as st
import librosa
import librosa.display
from torchvision import transforms, models
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

# Function to plot waveform
def plot_waveform(y, sr):
    plt.figure(figsize=(10, 4))
    librosa.display.waveshow(y, sr=sr)
    plt.title('Waveform')
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    st.pyplot(plt)

# Function to plot MEL spectrogram
def plot_mel_spectrogram(y, sr):
    S = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=128)
    S_DB = librosa.power_to_db(S, ref=np.max)
    plt.figure(figsize=(10, 4))
    librosa.display.specshow(S_DB, sr=sr, x_axis='time', y_axis='mel')
    plt.colorbar(format='%+2.0f dB')
    plt.title('MEL Spectrogram')
    plt.xlabel('Time (s)')
    plt.ylabel('Mel Frequency')
    st.pyplot(plt)

# Function to plot MFCC
def plot_mfcc(y, sr):
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    plt.figure(figsize=(10, 4))
    librosa.display.specshow(mfccs, sr=sr, x_axis='time')
    plt.colorbar()
    plt.title('MFCC')
    plt.xlabel('Time (s)')
    plt.ylabel('MFCC Coefficients')
    st.pyplot(plt)

# Streamlit app
st.title('Audio File Analysis')
st.subheader('Upload your audio file below')

# File uploader for audio files
uploaded_file = st.file_uploader("Choose an audio file", type=['wav', 'mp3', 'aac', 'flac', 'ogg'])

df = pd.read_csv('esc50.csv')

gt = df['target'].unique()
indexes = np.unique(gt, return_index=True)[1]
classes = [gt[index] for index in sorted(indexes)]
class_names = df['category'].unique()

# Create a dictionary that maps numerical targets to class names
class_dict = {i: class_name for i, class_name in zip(classes, class_names)}

if uploaded_file:
    st.audio(uploaded_file, format='audio/wav')
    st.subheader('Audio File Information')
    
    # Load the audio file
    y, sr = librosa.load(uploaded_file, sr=None)
    
    n_samples = int((16000 / 1000) * 3000)
    
    mode = st.selectbox("Which network do you want to use?", ("AudioNet", "TransferNet"))
    
    # Display audio file information
    st.write(f'Sample Rate: {sr} Hz')
    st.write(f'Duration: {librosa.get_duration(y=y, sr=sr):.2f} seconds')

    # Plot and display waveform
    st.subheader('Waveform')
    plot_waveform(y, sr)

    # Plot and display MEL spectrogram
    st.subheader('MEL Spectrogram')
    plot_mel_spectrogram(y, sr)

    # Plot and display MFCC
    st.subheader('MFCC')
    plot_mfcc(y, sr)
    
    if mode == "AudioNet":
        if len(y.shape) > 1:
            y = librosa.to_mono(y)
        # resample to 16000 Hz
        if sr != 16000:
            y = librosa.resample(y, orig_sr=sr, target_sr=16000)
        
        # replicate if audio is too short
        if len(y) < n_samples:
            y = np.tile(y, n_samples // len(y) + 1)
        # random crop to self.n_samples
        isrt = np.random.randint(0, len(y) - n_samples)
        iend = isrt + n_samples
        y = y[isrt:iend]
        # compute win_length and hop_length for mfcc
        win_length = int((16000 / 1000) * 30)  # 30 ms
        hop_length = int((16000 / 1000) * 15)  # 15 ms
        # compute 40 MFCCs with previous parameters (n_mfcc=40)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40, win_length=win_length, hop_length=hop_length)
        
        class Net(nn.Module):
            def __init__(self):
                super(Net, self).__init__()
                self.conv1 = nn.Conv2d(in_channels=1, out_channels=32, kernel_size=5, stride=2)
                self.norm1 = nn.BatchNorm2d(32, eps=1e-05, momentum=0.1)
                self.dropout = nn.Dropout(0.25)
                self.pool = nn.MaxPool2d(2)
                self.conv2 = nn.Conv2d(32, 64, 5)
                self.norm2 = nn.BatchNorm2d(64, eps=1e-05, momentum=0.1)
                self.conv3 = nn.Conv2d(64, 128, 3, padding=1)
                self.norm3 = nn.BatchNorm2d(128, eps=1e-05, momentum=0.1)
                self.conv4 = nn.Conv2d(128, 256, 3, padding=1)
                self.norm4 = nn.BatchNorm2d(256, eps=1e-05, momentum=0.1)
                
                # Placeholder for the first fully-connected layer
                self.fc1 = nn.Linear(256, 128)  # Updated based on the input size
                self.fc2 = nn.Linear(128, 50)
        
            def forward(self, x):
                x = self.pool(F.relu(self.conv1(x)))
                x = self.dropout(x)
                x = self.norm1(x)
                x = self.pool(F.relu(self.conv2(x)))
                x = self.dropout(x)
                x = self.norm2(x)
                x = self.pool(F.relu(self.conv3(x)))
                x = self.dropout(x)
                x = self.norm3(x)
                x = F.relu(self.conv4(x))
                x = self.dropout(x)
                x = self.norm4(x)
        
                # Temporal aggregation
                x = x.mean(-1)
                x = x.squeeze(-1)  # Equivalent to reshape
        
        #         # Print the shape to debug
        #         print("Shape before flattening:", x.shape)
        
                x = x.view(x.size(0), -1)  # Flatten the tensor
                x = F.relu(self.fc1(x))
                x = self.dropout(x)
                x = self.fc2(x)
                return x
            
        audionet = Net()
        audionet.load_state_dict(torch.load('AudioNet.pth', map_location=torch.device('cpu')))
        audionet.eval()
        with torch.no_grad():
            output = audionet(torch.Tensor(mfcc).reshape(1, 1, 40, 201))
        pred = torch.max(output, 1)[1]
        st.success(class_dict[int(pred)])

    if mode =="TransferNet":
        if len(y.shape) > 1:
            y = librosa.to_mono(y)
        # resample to 16000 Hz
        if sr != 16000:
            y = librosa.resample(y, orig_sr=sr, target_sr=16000)
        
        # replicate if audio is too short
        if len(y) < n_samples:
            y = np.tile(y, n_samples // len(y) + 1)
        # random crop to self.n_samples
        isrt = np.random.randint(0, len(y) - n_samples)
        iend = isrt + n_samples
        y = y[isrt:iend]
        # compute win_length and hop_length for mfcc
        win_length = int((16000 / 1000) * 30)  # 30 ms
        hop_length = int((16000 / 1000) * 15)  # 15 ms
        # compute 40 MFCCs with previous parameters (n_mfcc=40)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40, win_length=win_length, hop_length=hop_length)
        mfcc = Image.fromarray(mfcc)
        
        transform = transform = transforms.Compose([
                                                        transforms.Grayscale(num_output_channels=3),  # Convert to 3 channels
                                                        transforms.Resize((256, 256)),
                                                        transforms.ToTensor(),
                                                    ])
        inp = transform(mfcc)
        
        # Load the MobileNetV2 model with pre-trained weights
        net = models.mobilenet_v2(weights='IMAGENET1K_V1')
        
        # Get the number of features for the classifier input
        num_ftrs = net.classifier[1].in_features
        
        class Classifier(nn.Module):
            def __init__(self):
                super(Classifier, self).__init__()
                self.fc1 = nn.Linear(num_ftrs, 500)
                self.dropout = nn.Dropout(0.4)
                self.fc2 = nn.Linear(500, 251)
                self.fc3 = nn.Linear(251, 50)
        
            def forward(self, x):
                x = x.view(x.size(0), -1)  # Flatten the tensor
                x = self.dropout(x)
                x = F.leaky_relu(self.fc1(x))
                x = self.dropout(x)
                x = F.leaky_relu(self.fc2(x))
                x = self.fc3(x)
                return F.log_softmax(x, dim=1)
        
        # Replace the classifier with the new classifier
        net.classifier = Classifier()
        
        net.load_state_dict(torch.load('AudioNet_transfer.pth', map_location=torch.device('cpu')))
        
        net.eval()
        
        with torch.no_grad():
            output = net(inp.unsqueeze(0))
            
        pred = torch.max(output, 1)[1]
        st.success(class_dict[int(pred)])